package com.example.cron.scheduler;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class TaskScheduler {

    @Scheduled(cron = "0 0 9 * * ?")
    public void sendOverdueReminder() {
        System.out.println("Sending daily overdue reminders...");
    }

    @Scheduled(cron = "0 0 10 * * ?")
    public void sendUpcomingDeadlineAlert() {
        System.out.println("Checking deadlines for next 7 days...");
    }

    @Scheduled(cron = "0 0 8 ? * MON")
    public void sendWeeklySummary() {
        System.out.println("Sending weekly summary...");
    }
}
