package com.example.demo.service;

import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import java.util.List;
import com.example.demo.entity.Item;
import com.example.demo.repo.ItemRepository;

@Service
public class ItemService {
 private final ItemRepository repo;
 public ItemService(ItemRepository repo){this.repo=repo;}

 public Page<Item> list(int page,int size,String sortBy,String sortDir){
   Sort sort = sortDir.equalsIgnoreCase("desc") ? Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
   Pageable pageable = PageRequest.of(page,size,sort);
   return repo.findAll(pageable);
 }

 public List<Item> findAll(){
   return repo.findAll();
 }

 public Item save(Item i){ return repo.save(i);}
}
