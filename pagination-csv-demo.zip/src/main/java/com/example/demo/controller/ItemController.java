package com.example.demo.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;
import java.util.*;
import com.example.demo.entity.Item;
import com.example.demo.service.ItemService;
import org.springframework.data.domain.Page;

@RestController
@RequestMapping("/items")
public class ItemController {

 private final ItemService service;
 public ItemController(ItemService service){this.service=service;}

 @GetMapping
 public Page<Item> list(
   @RequestParam(defaultValue="0") int page,
   @RequestParam(defaultValue="5") int size,
   @RequestParam(defaultValue="id") String sortBy,
   @RequestParam(defaultValue="asc") String sortDir
 ){
   return service.list(page,size,sortBy,sortDir);
 }

 @PostMapping
 public Item create(@RequestBody Item i){
   return service.save(i);
 }

 @GetMapping("/export")
 public ResponseEntity<String> exportCSV(){
   List<Item> items = service.findAll();
   StringBuilder sb = new StringBuilder();
   sb.append("id,name,category\n");
   for(Item i: items){
     sb.append(i.getId()).append(",")
       .append(i.getName()).append(",")
       .append(i.getCategory()).append("\n");
   }

   return ResponseEntity.ok()
     .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=items.csv")
     .contentType(MediaType.TEXT_PLAIN)
     .body(sb.toString());
 }
}
