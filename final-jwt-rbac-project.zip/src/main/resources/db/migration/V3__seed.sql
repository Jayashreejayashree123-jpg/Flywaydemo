
INSERT INTO users(username,password,role) VALUES
('admin','$2a$10$Dow1','ADMIN'),
('manager','$2a$10$Dow1','MANAGER'),
('viewer','$2a$10$Dow1','VIEWER');
