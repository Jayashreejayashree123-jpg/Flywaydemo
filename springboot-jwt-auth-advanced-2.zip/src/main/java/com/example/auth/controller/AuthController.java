
package com.example.auth.controller;

import com.example.auth.dto.*;
import com.example.auth.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

  @Autowired private AuthService service;

  @PostMapping("/register")
  public AuthResponse register(@RequestBody RegisterRequest r){
    return service.register(r);
  }

  @PostMapping("/login")
  public AuthResponse login(@RequestBody LoginRequest r){
    return service.login(r);
  }

  @PostMapping("/refresh")
  public AuthResponse refresh(@RequestBody String token){
    return service.refresh(token);
  }
}
