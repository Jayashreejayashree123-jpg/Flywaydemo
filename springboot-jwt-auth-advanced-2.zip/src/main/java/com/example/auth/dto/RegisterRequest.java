
package com.example.auth.dto;
public class RegisterRequest {
  public String username;
  public String password;
}
