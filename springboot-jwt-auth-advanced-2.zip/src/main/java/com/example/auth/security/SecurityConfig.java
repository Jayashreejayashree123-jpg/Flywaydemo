
package com.example.auth.security;

import org.springframework.context.annotation.*;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {
  @Bean
  public SecurityFilterChain filterChain(HttpSecurity http) throws Exception{
    http.csrf().disable()
      .authorizeHttpRequests()
      .requestMatchers("/auth/**").permitAll()
      .anyRequest().authenticated();
    return http.build();
  }
}
