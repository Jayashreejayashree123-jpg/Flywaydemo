
package com.example.auth.service;

import com.example.auth.dto.*;
import com.example.auth.entity.User;
import com.example.auth.repository.UserRepository;
import com.example.auth.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

  @Autowired private UserRepository repo;
  @Autowired private JwtUtil jwt;

  private BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

  public AuthResponse register(RegisterRequest r){
    User u = new User();
    u.setUsername(r.username);
    u.setPassword(encoder.encode(r.password));
    u.setRole("USER");
    repo.save(u);
    return tokens(u.getUsername());
  }

  public AuthResponse login(LoginRequest r){
    User u = repo.findByUsername(r.username).orElseThrow();
    if(!encoder.matches(r.password,u.getPassword())) throw new RuntimeException("Invalid");
    return tokens(u.getUsername());
  }

  public AuthResponse refresh(String token){
    String user = jwt.extractUsername(token);
    return tokens(user);
  }

  private AuthResponse tokens(String username){
    return new AuthResponse(jwt.generateAccessToken(username),
                            jwt.generateRefreshToken(username));
  }
}
