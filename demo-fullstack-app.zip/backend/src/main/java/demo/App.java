
package demo;

import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;
import org.springframework.web.bind.annotation.*;
import java.util.*;
import java.util.stream.*;
import java.io.*;

@SpringBootApplication
@RestController
@RequestMapping("/api")
public class App {

    static List<Map<String,String>> data = new ArrayList<>();

    public static void main(String[] args){
        SpringApplication.run(App.class,args);
    }

    @PostMapping("/create")
    public Map<String,String> create(@RequestBody Map<String,String> req){
        req.put("status","NEW");
        data.add(req);
        System.out.println("AUDIT: Created " + req);
        System.out.println("EMAIL: Notification sent");
        return req;
    }

    @PutMapping("/update/{name}")
    public Map<String,String> update(@PathVariable String name){
        for(Map<String,String> d : data){
            if(d.get("name").equals(name)){
                d.put("status","UPDATED");
                System.out.println("AUDIT: Updated " + d);
                return d;
            }
        }
        return Map.of("error","not found");
    }

    @GetMapping("/search")
    public List<Map<String,String>> search(@RequestParam String keyword){
        return data.stream()
            .filter(d -> d.get("name").contains(keyword))
            .collect(Collectors.toList());
    }

    @GetMapping("/export")
    public String export() throws Exception{
        StringWriter sw = new StringWriter();
        sw.append("name,status\n");
        for(Map<String,String> d: data){
            sw.append(d.get("name")+","+d.get("status")+"\n");
        }
        return sw.toString();
    }
}
