package com.example.taskmanager.service;
import com.example.taskmanager.entity.Task;
import com.example.taskmanager.repository.TaskRepository;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;

@Service
public class TaskService {
    private final TaskRepository repo;
    public TaskService(TaskRepository repo) { this.repo = repo; }

    public List<Task> search(String keyword) { return repo.searchByTitle(keyword); }
    public List<Task> getByStatus(String status) { return repo.findByStatus(status); }
    public List<Task> getByDateRange(LocalDate start, LocalDate end) { return repo.findByDateRange(start, end); }
    public Task save(Task task) { return repo.save(task); }
    public List<Task> getAll() { return repo.findAll(); }
}