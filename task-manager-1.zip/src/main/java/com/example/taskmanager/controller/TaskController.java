package com.example.taskmanager.controller;
import com.example.taskmanager.entity.Task;
import com.example.taskmanager.service.TaskService;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/tasks")
public class TaskController {
    private final TaskService service;
    public TaskController(TaskService service) { this.service = service; }

    @PostMapping
    public Task create(@RequestBody Task task) { return service.save(task); }

    @GetMapping
    public List<Task> getAll() { return service.getAll(); }

    @GetMapping("/search")
    public List<Task> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/status")
    public List<Task> byStatus(@RequestParam String status) { return service.getByStatus(status); }

    @GetMapping("/date")
    public List<Task> byDate(@RequestParam LocalDate start, @RequestParam LocalDate end) {
        return service.getByDateRange(start, end);
    }
}