package com.example.app.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.*;

import com.example.app.entity.User;
import com.example.app.service.UserService;

@RestController
@RequestMapping("/users")
public class UserController {

 private final UserService service;

 public UserController(UserService service){
  this.service=service;
 }

 @GetMapping
 public Page<User> all(@RequestParam(defaultValue="0") int page,
                       @RequestParam(defaultValue="5") int size){
  return service.findAll(PageRequest.of(page,size));
 }

 @PostMapping
 public User create(@RequestBody User u){
  return service.save(u);
 }
}