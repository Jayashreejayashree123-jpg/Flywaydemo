package com.example.app.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import com.example.app.entity.User;
import com.example.app.repository.UserRepository;

@Service
public class UserService {
 private final UserRepository repo;

 public UserService(UserRepository repo){this.repo=repo;}

 public Page<User> findAll(Pageable pageable){
  return repo.findAll(pageable);
 }

 public User save(User u){
  return repo.save(u);
 }
}