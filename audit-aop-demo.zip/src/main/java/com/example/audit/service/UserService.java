package com.example.audit.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.Optional;
import com.example.audit.entity.AppUser;
import com.example.audit.repo.UserRepository;

@Service
public class UserService {
  private final UserRepository repo;

  public UserService(UserRepository repo) {
    this.repo = repo;
  }

  @Transactional
  public AppUser create(AppUser u) {
    return repo.save(u);
  }

  @Transactional
  public AppUser update(Long id, AppUser u) {
    AppUser existing = repo.findById(id).orElseThrow();
    existing.setName(u.getName());
    existing.setEmail(u.getEmail());
    return repo.save(existing);
  }

  @Transactional
  public void delete(Long id) {
    repo.deleteById(id);
  }

  public Optional<AppUser> find(Long id) {
    return repo.findById(id);
  }
}
