package com.example.audit.controller;

import org.springframework.web.bind.annotation.*;
import java.util.Optional;
import com.example.audit.entity.AppUser;
import com.example.audit.service.UserService;

@RestController
@RequestMapping("/users")
public class UserController {
  private final UserService service;

  public UserController(UserService service) { this.service = service; }

  @PostMapping
  public AppUser create(@RequestBody AppUser u) { return service.create(u); }

  @PutMapping("/{id}")
  public AppUser update(@PathVariable Long id, @RequestBody AppUser u) {
    return service.update(id, u);
  }

  @DeleteMapping("/{id}")
  public void delete(@PathVariable Long id) { service.delete(id); }

  @GetMapping("/{id}")
  public Optional<AppUser> get(@PathVariable Long id) { return service.find(id); }
}
