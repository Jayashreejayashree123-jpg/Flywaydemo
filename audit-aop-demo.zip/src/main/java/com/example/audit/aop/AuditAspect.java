package com.example.audit.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;
import com.example.audit.repo.AuditLogRepository;
import com.example.audit.entity.AuditLog;
import com.fasterxml.jackson.databind.ObjectMapper;

@Aspect
@Component
public class AuditAspect {

  private final AuditLogRepository repo;
  private final ObjectMapper mapper = new ObjectMapper();

  public AuditAspect(AuditLogRepository repo) { this.repo = repo; }

  @Around("execution(* com.example.audit.service.*.create(..)) || " +
          "execution(* com.example.audit.service.*.update(..)) || " +
          "execution(* com.example.audit.service.*.delete(..))")
  public Object audit(ProceedingJoinPoint pjp) throws Throwable {
    Object result = null;
    String method = pjp.getSignature().getName();
    String op = method.equals("create") ? "CREATE" :
                method.equals("update") ? "UPDATE" : "DELETE";

    String oldJson = null;
    String newJson = null;

    try {
      if (op.equals("UPDATE") || op.equals("DELETE")) {
        // simplistic: first arg id, fetch via reflection if needed (skipped for brevity)
      }

      result = pjp.proceed();

      if (result != null) {
        newJson = mapper.writeValueAsString(result);
      }

      AuditLog log = new AuditLog();
      log.setEntityName("AppUser");
      log.setOperation(op);
      log.setMethod(method);
      log.setOldValue(oldJson);
      log.setNewValue(newJson);
      repo.save(log);

      return result;
    } catch (Throwable ex) {
      throw ex;
    }
  }
}
