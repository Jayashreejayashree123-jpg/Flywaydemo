package com.example.audit.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.audit.entity.AppUser;

public interface UserRepository extends JpaRepository<AppUser, Long> {}
