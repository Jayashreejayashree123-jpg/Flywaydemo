package com.example.audit.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.audit.entity.AuditLog;

public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {}
