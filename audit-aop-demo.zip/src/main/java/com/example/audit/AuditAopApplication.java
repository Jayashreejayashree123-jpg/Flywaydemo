package com.example.audit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuditAopApplication {
  public static void main(String[] args) {
    SpringApplication.run(AuditAopApplication.class, args);
  }
}
