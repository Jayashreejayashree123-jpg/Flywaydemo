package com.example.audit.entity;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "audit_log")
public class AuditLog {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private String entityName;
  private String operation; // CREATE, UPDATE, DELETE
  private String method;

  @Lob
  private String oldValue;

  @Lob
  private String newValue;

  private Instant createdAt = Instant.now();

  public Long getId() { return id; }
  public String getEntityName() { return entityName; }
  public void setEntityName(String entityName) { this.entityName = entityName; }
  public String getOperation() { return operation; }
  public void setOperation(String operation) { this.operation = operation; }
  public String getMethod() { return method; }
  public void setMethod(String method) { this.method = method; }
  public String getOldValue() { return oldValue; }
  public void setOldValue(String oldValue) { this.oldValue = oldValue; }
  public String getNewValue() { return newValue; }
  public void setNewValue(String newValue) { this.newValue = newValue; }
  public Instant getCreatedAt() { return createdAt; }
}
