CREATE TABLE audit_log (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    entity_type VARCHAR(100) NOT NULL,
    entity_id BIGINT NOT NULL,
    action VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(100)
);

-- Composite index
CREATE INDEX idx_entity_type_id 
ON audit_log(entity_type, entity_id);

-- Additional indexes
CREATE INDEX idx_created_at ON audit_log(created_at);
CREATE INDEX idx_action ON audit_log(action);
CREATE INDEX idx_created_by ON audit_log(created_by);
