
package com.example.demo;

import com.example.demo.model.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Testcontainers
class UserIntegrationTest {

    @Container
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:15");

    @Container
    static GenericContainer<?> redis = new GenericContainer<>("redis:7").withExposedPorts(6379);

    @LocalServerPort
    int port;

    @Autowired
    TestRestTemplate rest;

    @Test
    void fullCrudFlow() {
        String base = "http://localhost:" + port + "/users";

        User user = new User(1L, "John", "john@test.com");

        var created = rest.postForEntity(base, user, User.class);
        assertThat(created.getStatusCode().value()).isEqualTo(201);

        var fetched = rest.getForEntity(base + "/1", User.class);
        assertThat(fetched.getStatusCode().value()).isEqualTo(200);

        rest.delete(base + "/1");

        var afterDelete = rest.getForEntity(base + "/1", User.class);
        assertThat(afterDelete.getStatusCode().value()).isEqualTo(404);
    }
}
