# Spring Boot Project

Ready-to-run project with Docker and tests.
