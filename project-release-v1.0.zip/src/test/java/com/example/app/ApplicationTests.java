package com.example.app;
import org.junit.jupiter.api.Test;
class ApplicationTests {
  @Test
  void contextLoads() {}
}