package com.example.audit.repository;

import com.example.audit.entity.AuditLog;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface AuditRepository extends JpaRepository<AuditLog, Long> {

    @Query("SELECT a FROM AuditLog a WHERE a.deleted=false AND " +
           "(LOWER(a.action) LIKE LOWER(CONCAT('%', :q, '%')) OR " +
           "LOWER(a.status) LIKE LOWER(CONCAT('%', :q, '%')))")
    List<AuditLog> search(@Param("q") String q);

    @Query("SELECT COUNT(a) FROM AuditLog a WHERE a.deleted=false")
    long countActive();

    @Query("SELECT COUNT(a) FROM AuditLog a WHERE a.deleted=true")
    long countDeleted();
}