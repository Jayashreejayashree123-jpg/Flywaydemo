package com.example.audit.controller;

import com.example.audit.entity.AuditLog;
import com.example.audit.service.AuditService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/audit")
public class AuditController {

    @Autowired
    private AuditService service;

    @PutMapping("/{id}")
    public AuditLog update(@PathVariable Long id, @RequestBody AuditLog log) {
        return service.update(id, log);
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable Long id) {
        service.softDelete(id);
        return "Deleted";
    }

    @GetMapping("/search")
    public List<AuditLog> search(@RequestParam String q) {
        return service.search(q);
    }

    @GetMapping("/stats")
    public long[] stats() {
        return service.stats();
    }
}