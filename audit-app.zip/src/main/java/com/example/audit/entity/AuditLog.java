package com.example.audit.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String entityType;
    private Long entityId;
    private String action;
    private String status;
    private boolean deleted = false;

    private LocalDateTime createdAt = LocalDateTime.now();

    public Long getId() { return id; }
    public String getAction() { return action; }
    public String getStatus() { return status; }

    public void setAction(String action) { this.action = action; }
    public void setStatus(String status) { this.status = status; }
    public void setDeleted(boolean deleted) { this.deleted = deleted; }
}