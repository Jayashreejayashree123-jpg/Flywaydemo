package com.example.audit.service;

import com.example.audit.entity.AuditLog;
import com.example.audit.repository.AuditRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class AuditService {

    @Autowired
    private AuditRepository repo;

    public AuditLog update(Long id, AuditLog updated) {
        AuditLog log = repo.findById(id).orElseThrow();
        log.setAction(updated.getAction());
        log.setStatus(updated.getStatus());
        return repo.save(log);
    }

    public void softDelete(Long id) {
        AuditLog log = repo.findById(id).orElseThrow();
        log.setDeleted(true);
        repo.save(log);
    }

    public List<AuditLog> search(String q) {
        return repo.search(q);
    }

    public long[] stats() {
        return new long[]{repo.countActive(), repo.countDeleted()};
    }
}