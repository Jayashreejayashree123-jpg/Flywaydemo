# Project Release v1.0

## ✅ Status
- P1 Bugs: 0
- P2 Bugs: 0
- P3 Bugs: Documented below

## ⚠️ Known Issues (P3)
1. CSV export may slow for very large datasets (>100k rows)
2. Pagination sorting limited to indexed fields
3. Audit logs stored as JSON (no diff viewer UI yet)

## 🚀 Run
mvn clean package
docker-compose up --build

## 📌 Features
- CRUD APIs
- Pagination & Sorting
- Audit Logging (basic)
- CSV Export
- Dockerized
