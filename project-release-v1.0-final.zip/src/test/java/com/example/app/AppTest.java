package com.example.app;
import org.junit.jupiter.api.Test;
class AppTest {
 @Test void test(){ assert true; }
}