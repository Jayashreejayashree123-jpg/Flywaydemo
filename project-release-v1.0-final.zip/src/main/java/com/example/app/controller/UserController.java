package com.example.app.controller;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import com.example.app.service.UserService;
import com.example.app.entity.User;

@RestController
@RequestMapping("/users")
public class UserController {
 private final UserService service;
 public UserController(UserService service){this.service=service;}

 @GetMapping
 public List<User> all(){return service.findAll();}

 @PostMapping
 public User create(@RequestBody User u){return service.save(u);}
}