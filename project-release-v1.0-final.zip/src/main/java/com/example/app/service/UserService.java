package com.example.app.service;
import org.springframework.stereotype.Service;
import java.util.List;
import com.example.app.repository.UserRepository;
import com.example.app.entity.User;

@Service
public class UserService {
 private final UserRepository repo;
 public UserService(UserRepository repo){this.repo=repo;}
 public List<User> findAll(){return repo.findAll();}
 public User save(User u){return repo.save(u);}
}