
package com.example.taskmanager.scheduler;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
public class SchedulerService {

  @Scheduled(cron="0 0 9 * * ?")
  public void fixP1Crash(){
    System.out.println("P1 crashes fixed check");
  }

  @Scheduled(cron="0 0 8 * * ?")
  public void fixP2Data(){
    System.out.println("P2 data fix check");
  }
}
